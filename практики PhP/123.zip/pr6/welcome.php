<!DOCTYPE html>
<html>
<head>
    <title>Добро пожаловать</title>
</head>
<body>
    <h2>Добро пожаловать!</h2>
    <a href="logout.php">Выйти</a>
</body>
</html>
